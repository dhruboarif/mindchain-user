<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PerryMindController extends Controller
{
    //
}
