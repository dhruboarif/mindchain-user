<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StakingSetting extends Model
{
    use HasFactory;
    protected $table ="staking_settings";
}
